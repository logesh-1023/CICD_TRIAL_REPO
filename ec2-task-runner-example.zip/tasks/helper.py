def helper_func():
    print("This is a helper function.")
