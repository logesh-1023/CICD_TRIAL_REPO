import sys
def main():
    print("Running model.py with args:", sys.argv[1:])

if __name__ == "__main__":
    main()
